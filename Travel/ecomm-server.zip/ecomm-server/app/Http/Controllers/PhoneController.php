<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Models\Phone;
use App\Models\User;
use Illuminate\Http\Request;
use Validator;
use File;

class PhoneController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // return Phone::all();
        
        $product = Phone::all();
    	return view('dashboardadmin.listproduct')->with('product', $product);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = User::all();
    	return view('dashboardadmin.createproduct',compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'name' => 'required|max:20|min:3',
            'description' => 'required|max:1000|min:50',
            'price' => 'required|max:20|min:3',
            'img' => 'required|mimes:jpg,jpeg,png,gif',
        ]);
        if ($validator->fails()) {
            return redirect('/product')
                ->withInput()
                ->withErrors($validator);
        }

        $image = $request->file('img');
        $upload = $image->getClientOriginalName();
        $pathurl = 'images/phones/';
        $path = move_uploaded_file($image->getPathName(), $pathurl. $upload);

        $phone = new Phone;
        $post->user_id = $request->user_id;
        $phone->name = $request->name;
        $phone->description = $request->description;
        $phone->img = $upload;
        $phone->price = $request->price;
        $phone->save();
        return redirect('/product')->with('success','Post has created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Phone::find($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $phone = Phone::find($id);
        $phone->update($request->all());
        return $phone;
    }

    /**
     * Search the specified name
     *
     * @param  str  $name
     * @return \Illuminate\Http\Response
     */
    public function search($name)
    {
        return Phone::where('name','like','%'.$name.'%')->get();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Phone::destroy($id);
    }
}
