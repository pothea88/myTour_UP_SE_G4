<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Phone extends Model
{
    use HasFactory;
    // protected $table = 'phones';
    protected $fillable = array('user_id','name','description','price','img');
    public function users() {
        return $this->belongsTo(User::class);
    }
    // protected $fillable = [
    //     'name',
    //     'description',
    //     'price',
    //     'img',
    // ];
}
