	<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
                    <h2 class="title1">List All Product</h2>
					<div class="table-responsive bs-example widget-shadow">
                    <a href="<?php echo url('/createproduct'); ?>" type="sumit" class="btn btn-primary btn-flat btn-pri"><i class="fa fa-plus" aria-hidden="true"></i> Add product</a>
						<table class="table table-bordered"> 
							<thead> 
								<tr> 
									<th>User Id</th> 
									<th>Name Product</th> 
									<th>Description</th> 
									<th>Price</th> 
									<th>Image</th> 
									<th>Action</th> 
								</tr> 
							</thead> 
							<tbody>
							<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
								<tr> 
									<th scope="row"><?php echo e($products->user_id); ?></th> 
									<td><?php echo e($products->name); ?></td> 
									<td><?php echo e($products->description); ?></td> 
									<td><?php echo e($products->price); ?></td> 
									<td><?php echo e($products->img); ?></td> 
									<td>
										<a href="#" class="text-primary"><i class="fa fa-pencil" aria-hidden="true"></i></a>
										<a href="#" class="text-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
										<a href="#" class="text-success"><i class="fa fa-eye" aria-hidden="true"></i></a>
									</td>
								</tr> 
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody> 
						</table> 
					</div>
				</div>
			</div>
		</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboardadmin.adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/1TB/PostMedia/ecomm-server1/resources/views/dashboardadmin/listproduct.blade.php ENDPATH**/ ?>