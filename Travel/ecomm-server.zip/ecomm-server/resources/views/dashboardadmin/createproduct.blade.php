@extends('dashboardadmin.adminpage')
	@section('content')
    <div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h2 class="title1">Create Product</h2>
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
                        <a href="{!!url('/product')!!}" type="sumit"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back</a>
						</div>
						<div class="form-body">
							<form action="{{ route('product.store')}}" method="POST" enctype="multipart/form-data">
                            @csrf
                        @method('POST')
                            <div class="form-group"> 
                                    <label for="exampleInputEmail1">Product Name</label> 
                                    <input type="text" class="form-control" id="name" name="name"  placeholder="Product Name" required> 
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Select User</label>
                                    <select  name="user_id" id="user_id" class="form-control">
                                        @foreach ($users as $user) 
                                            <option value="{{ $user->id }}">{{$user->first_name}} {{$user->last_name}}</option>
                                       @endforeach
                                    </select>
                                </div>
                                <div class="form-group shadow-textarea">
                                <label for="exampleFormControlTextarea6">Description</label>
                                    <textarea  name="description" id="description" class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="writ descript about phone..." required></textarea>
                                </div>
                                <div class="form-group"> 
                                    <label for="exampleInputPassword1">Price</label> 
                                    <input  name="price" id="price" type="number" class="form-control" id="exampleInputPassword1" placeholder="price" required> 
                                </div> 
                                <div class="form-group">
                                    <label for="exampleInputFile">File input</label> 
                                    <input type="file" id="img" name="img" class="file" multiple data-overwrite-initial="false">
                                </div>
                                 <button type="submit" class="btn btn-primary">Submit</button> 
                            </form> 
						</div>
					</div>
				</div>
			</div>
		</div>
    @endsection