@extends('dashboardadmin.adminpage')
	@section('content')
    <div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
                    <h2 class="title1">List All Product</h2>
					<div class="table-responsive bs-example widget-shadow">
                    <a href="{{ url('/createproduct') }}" class="btn btn-primary btn-flat btn-pri"><i class="fa fa-plus" aria-hidden="true"></i> Add product</a>
						<table class="table table-bordered"> 
							<thead> 
								<tr> 
									<th>User Id</th> 
									<th>Name Product</th> 
									<th>Description</th> 
									<th>Price</th> 
									<th>Image</th> 
									<th>Action</th> 
								</tr> 
							</thead> 
							<tbody>
							@foreach ( $product as $products)
							
								<tr> 
									<th scope="row">{{$products->user_id }}</th> 
									<td>{{$products->name }}</td> 
									<td>{{$products->description }}</td> 
									<td>{{$products->price }}</td> 
									<td>{{$products->img }}</td> 
									<td>
										<a href="#" class="text-primary"><i class="fa fa-pencil" aria-hidden="true"></i></a>
										<a href="#" class="text-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
										<a href="#" class="text-success"><i class="fa fa-eye" aria-hidden="true"></i></a>
									</td>
								</tr> 
								@endforeach
							</tbody> 
						</table> 
					</div>
				</div>
			</div>
		</div>
    @endsection